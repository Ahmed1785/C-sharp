﻿using System;

namespace basic
{
    class Program
    {
        public static void print255()
        {
            for(int i = 1; i <= 255; i++){
                Console.WriteLine(i);
            }
        }

        public static void PrintOdd255()
        {
            for(int i = 1; i <= 255; i++){
                if(i%2 == 1){
                    Console.WriteLine(i);
                }
            }
        }

        public static void Iterate()
        {
            int[] arrayOfInts = new int[10];
            for(int i = 0; i < arrayOfInts.Length; i++){
                    Console.WriteLine(arrayOfInts[i]);
                }
            }


        public static void PrintSum()
        {
            int sum = 0;
            for(int i = 1; i <= 255; i++){
                sum = sum + i;
                Console.WriteLine(sum);
            }
        }

        public static void Max()
        {
            int[] arrayOfInts = new int[10];
            int max = arrayOfInts[0];
            for(int i = 0; i < arrayOfInts.Length; i++){
                if(arrayOfInts[i] > max){
                    max = arrayOfInts[i];
                }
                Console.WriteLine(max);
            }
        }

        public static void avg()
        {
            int[] arrayOfInts = new int[10];
            int sum = 0;
            for(int i = 0; i < arrayOfInts.Length; i++){
                sum += arrayOfInts[i];
                int average = sum/arrayOfInts.Length;
                }
                Console.WriteLine(average);
            }

        static void Main(string[] args)
        {
            // print255();
            // PrintOdd255();
            // PrintSum();
            // Iterate();
            // Max();
            avg();
        }
    }
}

