namespace ConsoleApplication {
    public class Human {
        public string name = "";
        public int strength = 3;
        public int intelligence = 3;
        public int dextrexity = 3;
        public int health = 100;
        public int damage = 0;

        public Human(string thing, int val) {
            name = thing;
            strength = val;
            intelligence = val;
            dextrexity = val;
            health = val;
            damage = strength*5;
        }

        public void attack(int punch) {}
    }
}