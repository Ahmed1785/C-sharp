using System;

namespace wizard
{
    public class Samurai : Human
    {
        public Samurai(string person) : base(person)
        {
        }

        public Samurai(string person, int str, int intel, int dex, int hp) : base(person, str, intel, dex, hp)
        {
            name = person;
            strength = str;
            intelligence = intel;
            dexterity = dex;
            health = 200;
        }
        public void deathblow(object obj, int life) 
        {
            Random rand = new Random();
            life = rand.Next(0,51);
            Samurai lifeforce = obj as Samurai;
            if(lifeforce is life)
            {
                lifeforce.health = 0;
                Console.WriteLine("Bankai");
            }
            else
            {
                lifeforce.health -= 50;
            }
        }
        public void meditate(object obj) 
        {
            Samurai meditate = obj as Samurai;
            if(meditate != null)
            {
                meditate.health = 200;
                Console.WriteLine("You're fully healed");
            }
        }
    }
}