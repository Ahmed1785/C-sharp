﻿using System;
using System.Collections.Generic;

namespace boxed
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            List<object> flavors = new List<object>();
            flavors.Add(7);
            flavors.Add(28);
            flavors.Add(-1);
            flavors.Add(true);
            flavors.Add("chair");
            Console.WriteLine(flavors.Count);
            Console.WriteLine(flavors[3]);

            for (int i = 0; i < flavors.Count; i++){
                Console.WriteLine(flavors[i]);
                int sum = 0;
                if(flavors[i] is int){
                    sum += flavors[i];
                }
            }
        }
    }
}
